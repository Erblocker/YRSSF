while GLOBAL_read("live_status")=="true" do
  liveScreen()
end